#include <REGtenxTM52F5278B.h>

#include "typeAlias.h"

#include "display.h"
#include "init.h"
#include "keys.h"
#include "isr.h"
#include "main.h"
#include <INTRINS.H>
