#ifndef __isr_h
#define __isr_h
// Hal: exp: #define P_led P10 -----------------

// Const: exp: #define D_data 1 ----------------

// Globle Var -----------------------------------------
#ifdef __isr_c
bit b1ms;
#else
extern bit b1ms;
#endif

// Action Macro: exp: #define F_getData() ------

// Function ------------------------------------

#endif