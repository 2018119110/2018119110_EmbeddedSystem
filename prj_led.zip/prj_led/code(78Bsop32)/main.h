#ifndef __main_h
#define __main_h

#ifdef __main_c

#else

#endif

// Action Macro: exp: #define F_getData() ------

// Function ------------------------------------
void Delay(uint16_t time);

#endif