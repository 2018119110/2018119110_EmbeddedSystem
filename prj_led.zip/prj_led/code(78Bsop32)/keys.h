#ifndef __keys_h
#define __keys_h

#ifdef __keys_c

#else

#endif

// Action Macro: exp: #define F_getData() ------

// Function ------------------------------------
void GetKeys();
#endif