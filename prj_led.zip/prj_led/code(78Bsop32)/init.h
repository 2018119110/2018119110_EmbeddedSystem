#ifndef __init_h
#define __init_h

#ifdef __init_c

#else

#endif
// Action Macro: exp: #define F_getData() ------

// Function ------------------------------------
void SysInit();

#endif